# GoalEdge Picks — Authentication & Subscription Starter

This starter turns the GoalEdge Picks static prototype into a real application foundation.

## Stack
- Frontend: plain HTML/CSS/JavaScript
- Authentication + database: Supabase
- Payments/subscriptions: Stripe Checkout + Stripe Billing
- Backend: Node.js + Express
- Deployment: any static host for `frontend/` plus a Node host for `server/`

## What is included
- Registration
- Login/logout
- Password reset
- Authenticated dashboard
- Supabase Row Level Security (RLS)
- Subscription entitlement model
- Stripe Checkout session endpoint
- Stripe customer portal endpoint
- Stripe webhook endpoint
- Admin role foundation
- Prediction tables and access policies

## 1. Create Supabase project
Create a Supabase project, then run `supabase/schema.sql` in the SQL editor.

Copy the project's browser-safe URL and publishable/anon key into:
`frontend/js/config.js`

Never put a Supabase service-role/secret key in frontend code.

## 2. Configure authentication
In Supabase Auth settings:
- Enable Email/Password.
- Configure your Site URL and redirect URLs.
- For production, configure custom SMTP so password-reset and verification emails are reliable.

The password-reset flow in this starter uses Supabase's recovery flow.

## 3. Configure Stripe
Create a recurring Stripe Price for the Pro membership.

Set server environment variables from `.env.example`:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRO_PRICE_ID
- APP_URL
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY

The service-role key is server-only.

Run:
`cd server`
`npm install`
`npm start`

## 4. Stripe webhook
Point Stripe's webhook endpoint to:
`https://YOUR_API_HOST/api/stripe/webhook`

Listen for subscription/customer events. The webhook updates the `subscriptions` table.

## 5. Connect frontend
Open `frontend/js/config.js` and set:
- SUPABASE_URL
- SUPABASE_ANON_KEY
- API_BASE_URL

For local development, `API_BASE_URL` can be `http://localhost:3000`.

## 6. Admin
A user's profile role can be changed to `admin` directly in Supabase after the account is created.

Do not expose admin/service credentials to the browser.

## Important production notes
- Use HTTPS in production.
- Do not trust client-side subscription state for premium access.
- Premium access is enforced with RLS in the database.
- Stripe webhook events are the source of truth for subscription state.
- Do not publish fabricated performance/results. Keep demo/sample data clearly labeled until real settled results exist.
- Avoid claims of guaranteed wins, fixed matches, or certainty.
- Add appropriate age/responsible-gambling notices for your target market.


## Pro subscription checkout

The dashboard now has a real Stripe Checkout flow.

1. In Stripe, create a recurring Product/Price for GoalEdge Pro.
2. Put its Price ID in `STRIPE_PRO_PRICE_ID`.
3. Set `APP_URL` to the URL where the frontend is hosted.
4. Start the API:
   `cd server && npm install && npm start`
5. Configure the Stripe webhook at:
   `/api/stripe/webhook`
6. Enable the Stripe Customer Portal in the Stripe Dashboard.
7. Make sure the Supabase schema has been applied before testing.

The browser never receives the Stripe secret key. The API verifies the user's Supabase access token before creating Checkout or Portal sessions.

For local testing, use Stripe test mode and a webhook forwarding tool such as Stripe CLI. Do not use live keys until HTTPS, webhook verification, RLS, email configuration, and production environment variables have been reviewed.


## Public website & deployment
The package now includes a polished public landing page, responsible-gambling page, contact placeholder, legal launch placeholder, and a production deployment checklist in `DEPLOYMENT.md`.
