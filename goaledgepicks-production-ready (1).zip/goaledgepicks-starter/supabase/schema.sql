-- GoalEdge Picks database foundation
create extension if not exists pgcrypto;

create type public.user_role as enum ('user', 'admin');
create type public.subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'unpaid', 'incomplete', 'incomplete_expired');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  role public.user_role not null default 'user',
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  status public.subscription_status not null default 'incomplete',
  price_id text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint subscriptions_one_row_per_user unique (user_id)
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  league text not null,
  home_team text not null,
  away_team text not null,
  kickoff_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists public.predictions (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  market text not null,
  selection text not null,
  confidence integer not null check (confidence between 0 and 100),
  is_premium boolean not null default true,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.prediction_results (
  id uuid primary key default gen_random_uuid(),
  prediction_id uuid not null unique references public.predictions(id) on delete cascade,
  result text not null check (result in ('won', 'lost', 'void', 'pending')),
  settled_at timestamptz
);


create table if not exists public.stripe_events (
  id text primary key,
  type text not null,
  created_at timestamptz not null default now()
);

alter table public.stripe_events enable row level security;

create index if not exists matches_kickoff_idx on public.matches(kickoff_at);
create index if not exists predictions_match_idx on public.predictions(match_id);
create index if not exists subscriptions_user_idx on public.subscriptions(user_id);

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.matches enable row level security;
alter table public.predictions enable row level security;
alter table public.prediction_results enable row level security;

-- Helper: active premium subscription
create or replace function public.has_active_subscription(uid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.subscriptions
    where user_id = uid
      and status in ('trialing', 'active')
      and (current_period_end is null or current_period_end > now())
  );
$$;

-- New-user profile creation
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- User profile access
create policy "users can read own profile"
on public.profiles for select
using (auth.uid() = id);

create policy "users can update own profile"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

-- Subscription access
create policy "users can read own subscription"
on public.subscriptions for select
using (auth.uid() = user_id);

-- Public match metadata
create policy "authenticated users can read matches"
on public.matches for select
to authenticated
using (true);

-- Premium predictions only for entitled users; admins can read all
create policy "entitled users can read published predictions"
on public.predictions for select
to authenticated
using (
  published = true
  and (
    is_premium = false
    or public.has_active_subscription(auth.uid())
    or exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  )
);

create policy "entitled users can read prediction results"
on public.prediction_results for select
to authenticated
using (
  exists (
    select 1
    from public.predictions p
    where p.id = prediction_id
      and p.published = true
      and (
        p.is_premium = false
        or public.has_active_subscription(auth.uid())
        or exists (
          select 1 from public.profiles
          where id = auth.uid() and role = 'admin'
        )
      )
  )
);

-- Admin write policies
create policy "admins manage matches"
on public.matches for all
to authenticated
using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
)
with check (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);

create policy "admins manage predictions"
on public.predictions for all
to authenticated
using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
)
with check (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);

create policy "admins manage results"
on public.prediction_results for all
to authenticated
using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
)
with check (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);
