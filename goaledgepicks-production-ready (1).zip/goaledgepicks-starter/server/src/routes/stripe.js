import express from "express";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";
import { config } from "../config.js";

const router = express.Router();
const stripe = new Stripe(config.stripeSecretKey);
const supabaseAdmin = createClient(config.supabaseUrl, config.supabaseServiceRoleKey);

async function requireUser(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "Authentication required" });
    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: "Invalid session" });
    req.user = data.user;
    next();
  } catch {
    res.status(401).json({ error: "Authentication required" });
  }
}

function subscriptionStatus(status) {
  return ["trialing", "active", "past_due", "canceled", "unpaid", "incomplete", "incomplete_expired"].includes(status)
    ? status : "incomplete";
}

async function saveSubscription(sub, fallbackUserId = null) {
  const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer?.id;
  let userId = sub.metadata?.user_id || fallbackUserId || null;

  if (!userId && customerId) {
    const { data: existing } = await supabaseAdmin.from("subscriptions")
      .select("user_id").eq("stripe_customer_id", customerId).maybeSingle();
    userId = existing?.user_id || null;
  }
  if (!userId) return;

  const periodEnd = sub.items?.data?.[0]?.current_period_end
    ? new Date(sub.items.data[0].current_period_end * 1000).toISOString() : null;

  const { error } = await supabaseAdmin.from("subscriptions").upsert({
    user_id: userId,
    stripe_customer_id: customerId,
    stripe_subscription_id: sub.id,
    status: subscriptionStatus(sub.status),
    price_id: sub.items?.data?.[0]?.price?.id || null,
    current_period_end: periodEnd,
    updated_at: new Date().toISOString()
  }, { onConflict: "user_id" });
  if (error) throw error;
}

// Stripe must receive the unparsed body for signature verification.
router.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], config.stripeWebhookSecret);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    const { error: eventError } = await supabaseAdmin.from("stripe_events").insert({
      id: event.id,
      type: event.type
    });
    if (eventError?.code === "23505") return res.json({ received: true, duplicate: true });
    if (eventError) throw eventError;

    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      if (session.mode === "subscription" && session.subscription) {
        const sub = await stripe.subscriptions.retrieve(session.subscription);
        await saveSubscription(sub, session.metadata?.user_id || session.client_reference_id || null);
      }
    }

    if (["customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"].includes(event.type)) {
      await saveSubscription(event.data.object);
    }

    return res.json({ received: true });
  } catch (err) {
    console.error("Stripe webhook processing failed", err);
    return res.status(500).json({ error: "Webhook processing failed" });
  }
});

router.use(express.json());

router.post("/checkout", requireUser, async (req, res) => {
  try {
    const { data: existing } = await supabaseAdmin.from("subscriptions")
      .select("stripe_customer_id,status").eq("user_id", req.user.id).maybeSingle();

    if (["active", "trialing"].includes(existing?.status)) {
      return res.status(409).json({ error: "You already have an active Pro subscription." });
    }

    let customerId = existing?.stripe_customer_id || null;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: req.user.email, metadata: { user_id: req.user.id } });
      customerId = customer.id;
      const { error } = await supabaseAdmin.from("subscriptions").upsert({
        user_id: req.user.id, stripe_customer_id: customerId, status: "incomplete", updated_at: new Date().toISOString()
      }, { onConflict: "user_id" });
      if (error) throw error;
    }

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: config.stripeProPriceId, quantity: 1 }],
      success_url: `${config.appUrl}/frontend/dashboard.html?checkout=success`,
      cancel_url: `${config.appUrl}/frontend/dashboard.html?checkout=cancelled`,
      client_reference_id: req.user.id,
      metadata: { user_id: req.user.id },
      subscription_data: { metadata: { user_id: req.user.id } },
      allow_promotion_codes: true
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not create checkout session" });
  }
});

router.post("/portal", requireUser, async (req, res) => {
  try {
    const { data: subscription } = await supabaseAdmin.from("subscriptions")
      .select("stripe_customer_id").eq("user_id", req.user.id).not("stripe_customer_id", "is", null).maybeSingle();
    if (!subscription?.stripe_customer_id) return res.status(404).json({ error: "No Stripe customer found for this account." });
    const portal = await stripe.billingPortal.sessions.create({ customer: subscription.stripe_customer_id, return_url: `${config.appUrl}/frontend/dashboard.html` });
    res.json({ url: portal.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not create portal session" });
  }
});

export default router;
