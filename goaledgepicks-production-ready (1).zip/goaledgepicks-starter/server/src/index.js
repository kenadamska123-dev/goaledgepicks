import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";
import { config } from "./config.js";
import stripeRouter from "./routes/stripe.js";

const app = express();
const supabaseAdmin = createClient(config.supabaseUrl, config.supabaseServiceRoleKey);

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin: config.frontendOrigin,
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json({ limit: "50kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: "draft-8", legacyHeaders: false }));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "goaledgepicks-api" }));

async function requireUser(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "Authentication required" });
    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: "Invalid session" });
    req.user = data.user;
    next();
  } catch {
    res.status(401).json({ error: "Authentication required" });
  }
}

app.get("/api/me", requireUser, async (req, res) => {
  const [{ data: profile }, { data: subscription }] = await Promise.all([
    supabaseAdmin.from("profiles").select("email,display_name,role,created_at").eq("id", req.user.id).maybeSingle(),
    supabaseAdmin.from("subscriptions").select("status,current_period_end,price_id,stripe_customer_id").eq("user_id", req.user.id).maybeSingle()
  ]);
  const active = !!subscription && ["active", "trialing"].includes(subscription.status) &&
    (!subscription.current_period_end || new Date(subscription.current_period_end) > new Date());
  res.json({ user: { id: req.user.id, email: req.user.email }, profile, subscription, active });
});

app.use("/api/stripe", stripeRouter);

app.use((_req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(config.port, () => console.log(`GoalEdge API listening on ${config.port}`));
