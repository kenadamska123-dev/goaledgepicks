import {supabase,requireSession,logout} from "./auth.js";

const cfg = window.GOAL_EDGE_CONFIG;
const session = await requireSession();
if (!session) throw new Error("No session");

const $ = (s) => document.querySelector(s);
$("#email").textContent = session.user.email || "Member";
$("#welcome").textContent =
  `Welcome back${session.user.user_metadata?.display_name ? ", " + session.user.user_metadata.display_name : ""}.`;

$("#logout").onclick = async () => {
  await logout();
  location.href = "auth.html";
};

async function api(path, options={}) {
  const {data} = await supabase.auth.getSession();
  const token = data.session?.access_token;
  const response = await fetch(`${cfg.API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
      Authorization: `Bearer ${token}`
    }
  });
  const body = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(body.error || "Request failed");
  return body;
}

async function loadSubscription() {
  const {data: sub} = await supabase
    .from("subscriptions")
    .select("status,current_period_end,stripe_customer_id")
    .eq("user_id", session.user.id)
    .maybeSingle();

  const active = sub && ["active","trialing"].includes(sub.status);
  $("#plan").textContent = active
    ? `Pro membership active${sub.current_period_end ? ` · renews ${new Date(sub.current_period_end).toLocaleDateString()}` : ""}`
    : "Free account";

  const action = $("#subscriptionAction");
  if (!action) return;

  action.textContent = active ? "Manage Pro subscription" : "Upgrade to Pro";
  action.onclick = async () => {
    action.disabled = true;
    action.textContent = "Opening…";
    try {
      const result = await api(active ? "/api/stripe/portal" : "/api/stripe/checkout", {
        method: "POST",
        body: JSON.stringify({})
      });
      window.location.href = result.url;
    } catch (e) {
      alert(e.message);
      action.disabled = false;
      action.textContent = active ? "Manage Pro subscription" : "Upgrade to Pro";
    }
  };
}

async function loadPredictions() {
  const {data,error} = await supabase
    .from("predictions")
    .select("id,market,selection,confidence,is_premium,matches(league,home_team,away_team,kickoff_at)")
    .eq("published",true)
    .order("created_at",{ascending:false})
    .limit(20);

  const picks = $("#picks");
  if (error) {
    picks.innerHTML = `<div class="card">Unable to load predictions.</div>`;
    return;
  }
  if (!data?.length) {
    picks.innerHTML = `<div class="card"><p class="muted">No published picks yet.</p></div>`;
    return;
  }

  picks.innerHTML = data.map(p => `
    <div class="card">
      <span class="pill">${p.matches?.league || "Football"}</span>
      <h3>${p.matches?.home_team || "Home"} vs ${p.matches?.away_team || "Away"}</h3>
      <p>${p.market}: <strong>${p.selection}</strong></p>
      <p class="muted">Confidence: ${p.confidence}%</p>
    </div>
  `).join("");
}

await loadSubscription();
await loadPredictions();
