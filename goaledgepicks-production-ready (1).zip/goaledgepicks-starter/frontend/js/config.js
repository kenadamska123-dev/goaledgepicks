// Browser-safe configuration only. Never place Supabase service-role or Stripe secret keys here.
window.GOAL_EDGE_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  API_BASE_URL: "http://localhost:3000"
};
