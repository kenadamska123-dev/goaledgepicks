import {supabase,requireSession,logout} from "./auth.js";

const session=await requireSession();
if(!session) throw new Error("No session");

const access=document.querySelector("#access");
const {data:profile,error:profileError}=await supabase
  .from("profiles").select("role,display_name").eq("id",session.user.id).single();

if(profileError || profile?.role!=="admin"){
  access.textContent="Access denied. This account is not an administrator.";
  document.querySelector("main").innerHTML="<h1>Access denied</h1><p class='muted'>Ask an existing administrator to assign the admin role.</p>";
  throw new Error("Not an admin");
}
access.textContent=`Signed in as ${profile.display_name||session.user.email} · Administrator`;

document.querySelector("#logout").onclick=async()=>{await logout();location.href="auth.html"};

async function loadMatches(){
  const {data,error}=await supabase.from("matches")
    .select("id,league,home_team,away_team,kickoff_at")
    .order("kickoff_at",{ascending:true}).limit(100);
  const select=document.querySelector("#match");
  select.innerHTML='<option value="">Select match</option>';
  if(error) return;
  for(const m of data||[]){
    const option=document.createElement("option");
    option.value=m.id;
    option.textContent=`${m.league} — ${m.home_team} vs ${m.away_team}`;
    select.appendChild(option);
  }
}

async function loadPredictions(){
  const {data,error}=await supabase.from("predictions")
    .select("id,market,selection,confidence,is_premium,published,created_at,matches(league,home_team,away_team)")
    .order("created_at",{ascending:false}).limit(50);
  if(error){document.querySelector("#tableWrap").textContent="Unable to load predictions.";return;}
  if(!data?.length){document.querySelector("#tableWrap").textContent="No predictions yet.";return;}
  document.querySelector("#tableWrap").innerHTML=`<table><thead><tr>
    <th>Match</th><th>Pick</th><th>Confidence</th><th>Tier</th><th>Published</th><th>Action</th>
  </tr></thead><tbody>${data.map(p=>`<tr>
    <td>${p.matches?.home_team||"—"} vs ${p.matches?.away_team||"—"}<br><small>${p.matches?.league||""}</small></td>
    <td>${p.market}: <strong>${p.selection}</strong></td>
    <td>${p.confidence}%</td>
    <td>${p.is_premium?"Premium":"Free"}</td>
    <td>${p.published?"Yes":"No"}</td>
    <td><button data-id="${p.id}" class="toggle">${p.published?"Unpublish":"Publish"}</button></td>
  </tr>`).join("")}</tbody></table>`;
  document.querySelectorAll(".toggle").forEach(btn=>btn.onclick=async()=>{
    const {data:row}=await supabase.from("predictions").select("published").eq("id",btn.dataset.id).single();
    if(!row)return;
    await supabase.from("predictions").update({published:!row.published}).eq("id",btn.dataset.id);
    loadPredictions();
  });
}

document.querySelector("#matchForm").onsubmit=async e=>{
 e.preventDefault();
 const s=document.querySelector("#matchStatus");s.textContent="Saving...";
 const value=document.querySelector("#kickoff").value;
 const kickoff=new Date(value).toISOString();
 const {error}=await supabase.from("matches").insert({
   league:document.querySelector("#league").value.trim(),
   home_team:document.querySelector("#home").value.trim(),
   away_team:document.querySelector("#away").value.trim(),
   kickoff_at:kickoff
 });
 s.textContent=error?error.message:"Match added.";
 if(!error){e.target.reset();loadMatches();}
};

document.querySelector("#predictionForm").onsubmit=async e=>{
 e.preventDefault();
 const s=document.querySelector("#predictionStatus");s.textContent="Saving...";
 const {error}=await supabase.from("predictions").insert({
   match_id:document.querySelector("#match").value,
   market:document.querySelector("#market").value.trim(),
   selection:document.querySelector("#selection").value.trim(),
   confidence:Number(document.querySelector("#confidence").value),
   is_premium:document.querySelector("#premium").value==="true",
   published:document.querySelector("#published").checked
 });
 s.textContent=error?error.message:"Prediction created.";
 if(!error){e.target.reset();loadPredictions();}
};

await loadMatches();
await loadPredictions();
